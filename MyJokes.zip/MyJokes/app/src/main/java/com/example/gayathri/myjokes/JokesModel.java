package com.example.gayathri.myjokes;

public class JokesModel {
    String joke;
    public JokesModel(  String joke) {


        this.joke = joke;
    }

    public String getJoke() {
        return joke;
    }

    public void setJoke(String joke) {
        this.joke = joke;
    }
}
